# Advik Biology website

A responsive static website built with HTML, CSS and vanilla JavaScript for GitHub Pages.

## Files
- `index.html` — page structure and content
- `styles.css` — responsive visual design
- `script.js` — mobile navigation and automatic footer year

## Publish on GitHub Pages
1. Open the repository that publishes `https://advik-biology.github.io`.
2. Upload/replace `index.html`, `styles.css` and `script.js` in the repository's publishing root (usually the `main` branch root).
3. Commit the changes.
4. In GitHub, open **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)` (if that is your existing setup), then save.
5. Wait for the Pages deployment to finish, then refresh your website. It may take a few minutes.

If your repository is named `advik-biology.github.io`, the root files publish to that domain. Keep any existing custom domain setting unchanged unless you intend to change it.

## Before publishing: personalise these placeholders
- Replace `YOUR-EMAIL@example.com` in `index.html` with an email address you control, or change the contact button to your chosen contact link.
- Replace “PDF coming soon” with a real PDF link only after you upload the notes. For example: `href="assets/human-reproduction-notes.pdf"`.
- Add only confirmed course details, schedules, fees, credentials and contact information. The current copy intentionally avoids inventing these details.
- Change the page title/description if you want a different public-facing description.

## Add a PDF
Create an `assets` folder in the repository, upload your PDF there, then change the matching resource link in `index.html` to its relative path, such as `assets/human-reproduction-notes.pdf`.

## Test locally
Open `index.html` in a browser. For a closer GitHub Pages preview, use a simple local static server or the GitHub Pages preview after publishing.
